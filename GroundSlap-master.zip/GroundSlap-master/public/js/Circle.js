class Circle {

    init() {
        let shape = pl.Circle
        let body;
        let fixture;
        

    }
}